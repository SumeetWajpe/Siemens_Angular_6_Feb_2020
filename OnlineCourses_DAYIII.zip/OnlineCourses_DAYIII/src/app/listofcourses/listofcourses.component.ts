import { Component, OnInit } from '@angular/core';
import { CourseModel } from '../course/course.model';
import { CourseService } from './courses.service';

@Component({
  selector: 'app-listofcourses',
  templateUrl: './listofcourses.component.html',
  styleUrls: ['./listofcourses.component.css']
})
export class ListofcoursesComponent{
  heading:string="Online Courses";
  courses:CourseModel[]=[];

  constructor(public servObj:CourseService){
      this.courses = this.servObj.listofcourses;
  } 

  ChangeHeadingHandler(){
    this.heading = "Udemy";
  }

  ChangeHeadingOnInput(evt){
   this.heading = evt.target.value;
  }
}
