import { Component, OnInit } from '@angular/core';
import { CurrentCartService } from './current-cart.service';

@Component({
  selector: 'app-current-cart',
  templateUrl: './current-cart.component.html',
  styleUrls: ['./current-cart.component.css']
})
export class CurrentCartComponent implements OnInit {

  constructor(public currCartServObj:CurrentCartService) { }


  ngOnInit() {
  }

}
