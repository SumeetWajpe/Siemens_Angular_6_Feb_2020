import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatCheckboxModule} from '@angular/material';
import {HttpClientModule} from '@angular/common/http';

import { AppComponent } from './app.component';
import { ListofcoursesComponent } from './listofcourses/listofcourses.component';
import { CourseComponent } from './course/course.component';
import { DurationPipe } from './duration.pipe';
import { ProductComponent } from './products/product.component';
import { ProductService } from './products/product.service';
import { CourseService } from './listofcourses/courses.service';
import { CurrentCartComponent } from './current-cart/current-cart.component';
import { CurrentCartService } from './current-cart/current-cart.service';
import { PostsComponent } from './posts/posts.component';
import { PostsService } from './posts/posts.service';
import { NewCoursetemplatedrivenFormComponent } from './new-coursetemplatedriven-form/new-coursetemplatedriven-form.component';
import { NewCoursemodelDrivenComponent } from './new-coursemodel-driven/new-coursemodel-driven.component';

@NgModule({
  declarations: [
    AppComponent, ListofcoursesComponent,
    CourseComponent, DurationPipe,
     ProductComponent,
     CurrentCartComponent,
     PostsComponent,
     NewCoursetemplatedrivenFormComponent,
     NewCoursemodelDrivenComponent
  ],
  imports: [
    BrowserModule,HttpClientModule,
    FormsModule,BrowserAnimationsModule,
    MatCheckboxModule,ReactiveFormsModule
  ],
  providers:[ProductService,CourseService,CurrentCartService],
  bootstrap: [AppComponent]
})
export class AppModule { }
