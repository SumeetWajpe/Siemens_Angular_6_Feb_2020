import { CourseModel} from '../course/course.model';

export class CurrentCartService{
    currentItems:CourseModel[] =[];

    addItemToCart(newCourse:CourseModel){        
        this.currentItems.push(newCourse);
        //console.log(this.currentItems);
    }
    removeItemFromCart(theId:number){  
        var index = this.currentItems.findIndex(i=>i.id == theId)      
        this.currentItems.splice(index,1);
        //console.log(this.currentItems);

    }
}