export class ProductService{
    products:string[] = ["Mobile","Laptop","LED TV"]

    getallProducts():string[]{
        return this.products;
    }

    addNewProduct(newProduct:string):void{
            this.products.push(newProduct);
    }
}