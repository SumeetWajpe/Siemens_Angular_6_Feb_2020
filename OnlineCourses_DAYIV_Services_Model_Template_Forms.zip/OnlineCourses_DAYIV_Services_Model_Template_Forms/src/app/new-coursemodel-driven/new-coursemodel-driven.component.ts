import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { CourseModel } from '../course/course.model';
import { CourseService } from '../listofcourses/courses.service';
import { restrictcourseNameValidator } from './customValidation';

@Component({
  selector: 'app-new-coursemodel-driven',
  templateUrl: './new-coursemodel-driven.component.html',
  styleUrls: ['./new-coursemodel-driven.component.css']
})
export class NewCoursemodelDrivenComponent implements OnInit {

  courseForm:FormGroup;
  newCourse:CourseModel = new CourseModel();
  constructor(public servObj:CourseService) { }


  ngOnInit() {
    this.courseForm = new FormGroup({
      'name':new FormControl(this.newCourse.name,
        [Validators.required,
          restrictcourseNameValidator(/Java/i)]),
      'price':new FormControl(this.newCourse.price),
      'quantity':new FormControl(this.newCourse.quantity),
      'rating':new FormControl(this.newCourse.rating),
      'likes':new FormControl(this.newCourse.likes),
      'imageurl':new FormControl(this.newCourse.ImageUrl),
      'duration':new FormControl(this.newCourse.duration)
    })
  }

  AddNewProduct(){
    this.servObj.addNewCourse(this.courseForm.value);
    this.newCourse = new CourseModel();
    this.courseForm.reset();
  }

}
