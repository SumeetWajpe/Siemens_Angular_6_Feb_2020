import {ValidatorFn,AbstractControl} from '@angular/forms';

// validator functions

export function restrictcourseNameValidator(courseNameRegex:RegExp):ValidatorFn{
        return (control:AbstractControl):{[key:string]:any} | null =>{
                var restrictedTitleName = courseNameRegex.test(control.value);
                return restrictedTitleName ? {'restrictedName':{value:control.value}} : null;
        }
}