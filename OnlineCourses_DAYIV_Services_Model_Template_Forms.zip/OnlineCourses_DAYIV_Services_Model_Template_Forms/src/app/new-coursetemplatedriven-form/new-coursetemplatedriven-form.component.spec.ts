import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewCoursetemplatedrivenFormComponent } from './new-coursetemplatedriven-form.component';

describe('NewCoursetemplatedrivenFormComponent', () => {
  let component: NewCoursetemplatedrivenFormComponent;
  let fixture: ComponentFixture<NewCoursetemplatedrivenFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewCoursetemplatedrivenFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewCoursetemplatedrivenFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
