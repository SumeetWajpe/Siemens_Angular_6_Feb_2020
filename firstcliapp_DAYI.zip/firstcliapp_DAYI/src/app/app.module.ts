import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import Product ,{Add,Multiplication} from './product.component';
import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent,Product
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
