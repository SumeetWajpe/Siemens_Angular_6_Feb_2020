import {Component, Input} from '@angular/core';
import { ProductModel } from './product.model';

@Component({
    selector:'app-product',
    templateUrl:'./product.component.html'
})
export default class ProductComponent{
    @Input()   productdetails:ProductModel =
     new ProductModel();
}

export  function Add(x,y){
    return x + y;
}

export  function Multiplication(x,y){
    return x * y;
}
    const PI = 3.14;