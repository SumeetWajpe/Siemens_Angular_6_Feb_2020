import { Component } from '@angular/core';
import {ProductModel} from './product.model';
@Component({
  selector: 'app-root',
 templateUrl:'./app.component.html'
})
export class AppComponent {

  imageurl:string="https://n4.sdlcdn.com/imgs/f/n/r/Gionee-A1-64GB-Black-SDL352791824-1-ff379.jpeg";

  products:ProductModel[] =[
    new ProductModel("Camera",30000),
    new ProductModel("Mobile",20000),
    new ProductModel("Drone",300000),
    new ProductModel("Shoes",3000)
  ];

}
