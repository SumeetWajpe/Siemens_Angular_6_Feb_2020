export class ProductModel{
    constructor(public name:string="Laptop",public price:number=20000){

    }
}