import { Component, OnInit } from '@angular/core';
import { CourseModel } from '../course/course.model';
import { CourseService } from '../listofcourses/courses.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-new-course-template',
  templateUrl: './new-coursetemplatedriven-form.component.html',
  styleUrls: ['./new-coursetemplatedriven-form.component.css']
})
export class NewCoursetemplatedrivenFormComponent implements OnInit {

  newCourse:CourseModel = new CourseModel();
  constructor(public servObj:CourseService,public router:Router) { }

  ngOnInit() {
  }

  AddNewProduct(f){
    // service method
      if(f.valid){
        this.servObj.addNewCourse(this.newCourse);
        this.newCourse = new CourseModel();
        f.reset();
        this.router.navigate(['/']);
      }
  }

}
