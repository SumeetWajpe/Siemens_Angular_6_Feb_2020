import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PostsService } from '../posts/posts.service';
import { PostsModel } from '../posts/posts.model';

@Component({
  selector: 'app-postdetails',
  templateUrl: './postdetails.component.html',
  styleUrls: ['./postdetails.component.css']
})
export class PostdetailsComponent implements OnInit {
  postId: number;
  thePost:PostsModel= new PostsModel();
  constructor(public currRoute: ActivatedRoute,
     public postServObj: PostsService) { }

  ngOnInit() {
    this.currRoute.params.subscribe(
      p => {
        this.postId = p.id;
        this.thePost = this.postServObj.allPosts.find(post=>post.id == p.id);
      }
    )
  }

}
