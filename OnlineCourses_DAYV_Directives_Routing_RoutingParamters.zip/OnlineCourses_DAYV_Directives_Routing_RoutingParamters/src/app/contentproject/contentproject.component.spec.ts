import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContentprojectComponent } from './contentproject.component';

describe('ContentprojectComponent', () => {
  let component: ContentprojectComponent;
  let fixture: ComponentFixture<ContentprojectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContentprojectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContentprojectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
