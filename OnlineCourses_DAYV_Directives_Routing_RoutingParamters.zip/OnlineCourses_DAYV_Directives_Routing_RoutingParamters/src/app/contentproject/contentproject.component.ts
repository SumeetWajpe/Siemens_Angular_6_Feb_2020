import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contentproject',
  templateUrl: './contentproject.component.html',
  styleUrls: ['./contentproject.component.css']
})
export class ContentprojectComponent implements OnInit {
  msg:string="Hello";
  constructor() { }

  ngOnInit() {
  }

}
