import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewCoursemodelDrivenComponent } from './new-coursemodel-driven.component';

describe('NewCoursemodelDrivenComponent', () => {
  let component: NewCoursemodelDrivenComponent;
  let fixture: ComponentFixture<NewCoursemodelDrivenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewCoursemodelDrivenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewCoursemodelDrivenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
