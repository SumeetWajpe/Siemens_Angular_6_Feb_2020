import { Component, OnInit } from '@angular/core';
import { CourseModel } from '../course/course.model';
import { CourseService } from './courses.service';

@Component({
  selector: 'app-listofcourses',
  templateUrl: './listofcourses.component.html',
  styleUrls: ['./listofcourses.component.css']
})
export class ListofcoursesComponent{
  heading:string="Online Courses";
  courses:CourseModel[]=[];
  courseName:string="";

  constructor(public servObj:CourseService){


    let aPromise  = this.servObj.getAllCourses();
    aPromise.then((response)=>{
      this.courses = response;
      this.servObj.listofcourses = response;
    } ,(err)=>console.log(err))


      //this.courses = this.servObj.listofcourses;
  } 

  ChangeHeadingHandler(){
    this.heading = "Udemy";
  }

  ChangeHeadingOnInput(evt){
   this.heading = evt.target.value;
  }
}
