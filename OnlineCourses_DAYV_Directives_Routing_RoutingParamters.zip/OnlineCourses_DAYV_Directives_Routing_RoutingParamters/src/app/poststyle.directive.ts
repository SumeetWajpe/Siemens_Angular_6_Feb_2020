import { Directive, ElementRef, OnInit, Input, HostListener } from '@angular/core';

@Directive({
  selector: '[appPoststyle]'
})
export class PoststyleDirective implements OnInit {

  @Input() color:string="lightyellow";
  constructor(public eleRef:ElementRef) { }
  ngOnInit(){
      this.eleRef.nativeElement.style.border = "1px solid red";
      this.eleRef.nativeElement.style.borderRadius = "5px";
      this.eleRef.nativeElement.style.margin = "5px";
      this.eleRef.nativeElement.style.padding = "5px"; 
      this.eleRef.nativeElement.style.backgroundColor = this.color;

  }

 @HostListener('mouseenter') StyleOnMouseEnter(){
  this.eleRef.nativeElement.style.backgroundColor = 'yellow';
  this.eleRef.nativeElement.style.cursor = 'pointer';
  //  this.eleRef.nativeElement.innerHTML = '<b>Hovered !</b>';

  }
  @HostListener('mouseleave') StyleOnMouseLeave(){
    this.eleRef.nativeElement.style.backgroundColor = this.color;

    }

}
