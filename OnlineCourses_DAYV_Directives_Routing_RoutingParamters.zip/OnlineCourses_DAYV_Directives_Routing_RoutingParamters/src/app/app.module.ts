import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatCheckboxModule} from '@angular/material';
import {HttpClientModule} from '@angular/common/http';
import { RouterModule, Routes} from '@angular/router';

import { AppComponent } from './app.component';
import { ListofcoursesComponent } from './listofcourses/listofcourses.component';
import { CourseComponent } from './course/course.component';
import { DurationPipe } from './duration.pipe';
import { ProductComponent } from './products/product.component';
import { ProductService } from './products/product.service';
import { CourseService } from './listofcourses/courses.service';
import { CurrentCartComponent } from './current-cart/current-cart.component';
import { CurrentCartService } from './current-cart/current-cart.service';
import { PostsComponent } from './posts/posts.component';
import { PostsService } from './posts/posts.service';
import { NewCoursetemplatedrivenFormComponent } from './new-coursetemplatedriven-form/new-coursetemplatedriven-form.component';
import { NewCoursemodelDrivenComponent } from './new-coursemodel-driven/new-coursemodel-driven.component';
import { PostdetailsComponent } from './postdetails/postdetails.component';
import { MessageComponent } from './message/message.component';
import { ContentprojectComponent } from './contentproject/contentproject.component';
import { PoststyleDirective } from './poststyle.directive';

const routes:Routes = [
  {path:'',component:ListofcoursesComponent},
  {path:'newcourse',component:NewCoursetemplatedrivenFormComponent},
  {path:'posts',component:PostsComponent},
  {path:'postdetails/:id',component:PostdetailsComponent},
  {path:'products',component:ProductComponent},
  {path:'contentprojection',component:ContentprojectComponent},

  {path:'**',redirectTo:'/'  }
];


@NgModule({
  declarations: [
    AppComponent, ListofcoursesComponent,
    CourseComponent, DurationPipe,
     ProductComponent,
     CurrentCartComponent,
     PostsComponent,
     NewCoursetemplatedrivenFormComponent,
     NewCoursemodelDrivenComponent,
     PostdetailsComponent,
     MessageComponent,
     ContentprojectComponent,
     PoststyleDirective
  ],
  imports: [
    BrowserModule,HttpClientModule,
    FormsModule,BrowserAnimationsModule,
    MatCheckboxModule,ReactiveFormsModule,
    RouterModule.forRoot(routes)
  ],
  providers:[ProductService,CourseService,CurrentCartService],
  bootstrap: [AppComponent]
})
export class AppModule { }
