import { PoststyleDirective } from './poststyle.directive';

describe('PoststyleDirective', () => {
  it('should create an instance', () => {
    const directive = new PoststyleDirective();
    expect(directive).toBeTruthy();
  });
});
