import { Component, OnInit } from '@angular/core';
import { PostsService } from './posts.service';
import { PostsModel } from './posts.model';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
})
export class PostsComponent implements OnInit {

  posts: PostsModel[] = [];
  constructor(public postsServObj: PostsService) {
    // Using Observable
       let observableofPosts =  this.postsServObj.getAllPosts();
       observableofPosts.subscribe((response)=>{
          this.posts = response;
          this.postsServObj.allPosts = response;
     })

    // let aPromise = this.postsServObj.getAllPosts();
    // aPromise.then(
    //   (response) => this.posts = response,
    //   (err) => console.log(err)
    // );// eof then
  }

  ngOnInit() {
  }

}
