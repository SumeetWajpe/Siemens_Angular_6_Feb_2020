import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { PostsModel } from './posts.model';
import { Observable } from 'rxjs';

@Injectable(
    {
        providedIn:'root'
    }
)
export class PostsService{
    allPosts:PostsModel[] = [];
    constructor(public httpServObj:HttpClient){

}
// Using Observable
     getAllPosts():Observable<PostsModel[]>{
        // makes an ajax request !
      return this.httpServObj.get<PostsModel[]>('https://jsonplaceholder.typicode.com/posts');
    }

    // Using Promise
    // getAllPosts(){
    //     // makes an ajax request !
    //   return this.httpServObj.get('https://jsonplaceholder.typicode.com/posts').toPromise();
      
    // }
}