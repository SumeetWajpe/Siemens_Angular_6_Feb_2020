import { Component, Input } from '@angular/core';
import { CourseModel } from './course.model';
import { CourseService } from '../listofcourses/courses.service';
import { CurrentCartService } from '../current-cart/current-cart.service';

@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent {
  @Input() coursedetails: CourseModel 
  = new CourseModel();

  isFree:boolean=false;
  isHighlighted:boolean = false;

  constructor(public courseservObj:CourseService,public currCartServObj:CurrentCartService ){

}

ngOnDestroy(){
  console.log('Destroying..')
}

AddToCart(){
  if(this.isHighlighted){
    this.currCartServObj.addItemToCart(this.coursedetails);
  }
  else{
    this.currCartServObj.removeItemFromCart(this.coursedetails.id);      
  }
}
}
