import { Component, OnInit, Input, OnChanges } from '@angular/core';

@Component({
  selector: 'app-message',
  templateUrl: './message.component.html',
  styleUrls: ['./message.component.css']
})
export class MessageComponent implements OnInit, OnChanges {

  @Input() inputMessage: string = "";
  constructor() {
    console.log('Within Ctor, input Message : ' + this.inputMessage)
  }

  ngOnChanges() {
    console.log('Within ngOnChanges, input Message : ' + this.inputMessage);
  }

  ngOnInit() {
    console.log('Within ngOnInit, input Message : ' + this.inputMessage)

  }

  ngAfterContentInit() {
    console.log('Within ngAfterContentInit, input Message : ' + this.inputMessage)

  }

  ngAfterContentChecked() {
    console.log('Within ngAfterContentChecked, input Message : ' + this.inputMessage)

  }

  ngAfterViewInit() {
    console.log('Within ngAfterViewInit, input Message : ' + this.inputMessage)

  }

  ngAfterViewChecked() {
    console.log('Within ngAfterViewChecked, input Message : ' + this.inputMessage)

  }

}
