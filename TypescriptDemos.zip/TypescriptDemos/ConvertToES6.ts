let es6Variable:number = 10000;

var es6Square = (x:any) => x *x;
