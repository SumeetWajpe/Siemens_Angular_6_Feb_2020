var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArrays = (this && this.__spreadArrays) || function () {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
};
var str = "Hello World !"; // type inference
// str = 10;  
var n; /// type annotation
n = 1000;
var s;
var b;
var o;
var anyTypeVar;
anyTypeVar = 10;
anyTypeVar = true;
anyTypeVar = [10, 20, 30];
console.log(str);
// let -> blocked scoped Var
if (true) {
    var x = 1000;
    // let x = 100000; // Error !
    if (true) {
        console.log(x);
    }
}
var PI = 3.14;
// Arrays
var cars = ["BMW", "AUDI", "FERRARI"];
var moreCars = new Array("TATA", "MAHINDRA");
// Spread Operator
var allCars = __spreadArrays(cars, moreCars);
console.log(allCars);
var person = { name: 'Virat', city: 'Delhi' };
var player = __assign(__assign({}, person), { runs: 40000 });
console.log(player.name);
// Functions 
function Add(x, y) {
    if (x < 0)
        return 'x should be greater than 0 !';
    return x + y;
}
var result = Add(20, 30);
// Optional Parameters
// function PrintBooks(title?:string,author?:string){
//     console.log(title,author);
// }
// PrintBooks();
// PrintBooks("Playing It My Way","Sachin Tendulkar");
// Default Parameters (Bydefault optional)
// function PrintBooks(title:string="Unknown",
// author:string="Unknown"){
//     console.log(title,author);
// }
// PrintBooks();
// PrintBooks(undefined,"Some Author");
// PrintBooks("Playing It My Way","Sachin Tendulkar");
// Rest Parameters
function PrintBooks(author) {
    var titles = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        titles[_i - 1] = arguments[_i];
    }
    console.log(author, titles);
}
PrintBooks("Virat Kohli", "Driven");
PrintBooks("Dr. APJ Abdul Kalam", "Wings Of Fire", "India 2020");
// function Square(x){
//     return x * x;
// }
// Function as expression
// var Square = function(x){
//     return x * x;
// }
// Arrow function (ES6)
// var Square = (x) => {
//     return x * x;
// }
// OR
// var Square =  x => x * x; // The JS way !
var Square = function (x) { return x * x; };
cars.forEach(function (theCar) {
    console.log(theCar);
});
// with arrow function
cars.forEach(function (theCar) { return console.log(theCar); });
var emp = { name: 'Amit',
    salary: 300000,
    getSalary: function () {
        return this.salary;
    } };
var EMPLOYEE = /** @class */ (function () {
    function EMPLOYEE() {
    }
    EMPLOYEE.prototype.getSalary = function () {
        return this.salary;
    };
    return EMPLOYEE;
}());
// Classes
var Car = /** @class */ (function () {
    function Car(name, speed) {
        if (name === void 0) { name = "i10"; }
        if (speed === void 0) { speed = 100; }
        this.name = name;
        this.speed = speed;
    }
    Car.prototype.accelerate = function () {
        //     console.log('The car ' 
        //     +this.name +
        //      " is running at " 
        //      + this.speed + " kmph !");
        return ("The car " + this.name + "  is running at " + this.speed + " kmph !");
    };
    return Car;
}());
var JamesBondCar = /** @class */ (function (_super) {
    __extends(JamesBondCar, _super);
    function JamesBondCar(n, s, fly, nitro) {
        var _this = _super.call(this, n, s) || this;
        _this.nitroPower = nitro;
        _this.canFly = fly;
        return _this;
    }
    JamesBondCar.prototype.accelerate = function () {
        return _super.prototype.accelerate.call(this) + "Can Fly ? : " + this.canFly;
    };
    return JamesBondCar;
}(Car));
var jbc = new JamesBondCar("Aston Martin", 500, true, true);
jbc.accelerate();
// Enhanced Class Syntax
var EnhancedCar = /** @class */ (function () {
    function EnhancedCar(name, speed) {
        if (name === void 0) { name = "i20"; }
        if (speed === void 0) { speed = 200; }
        this.name = name;
        this.speed = speed;
    }
    return EnhancedCar;
}());
var ec = new EnhancedCar();
