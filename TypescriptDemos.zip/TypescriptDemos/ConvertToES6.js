let es6Variable = 10000;
var es6Square = (x) => x * x;
