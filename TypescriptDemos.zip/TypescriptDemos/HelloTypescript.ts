var str = "Hello World !"; // type inference
// str = 10;  

var n:number; /// type annotation
n = 1000;

var s:string;
var b:boolean;
var o:object;
var anyTypeVar:any;
anyTypeVar = 10;
anyTypeVar = true;
anyTypeVar = [10,20,30];

console.log(str);
// let -> blocked scoped Var
if(true){
    let x = 1000;
    // let x = 100000; // Error !
    if(true){
        console.log(x);
    }
}
const PI:number = 3.14;

// Arrays

var cars:string[] = ["BMW","AUDI","FERRARI"];
var moreCars:Array<string> = new Array<string>("TATA","MAHINDRA");

// Spread Operator
var allCars = [...cars,...moreCars];

console.log(allCars);

var person = {name:'Virat',city:'Delhi'};

var player = {...person,runs:40000};
console.log(player.name);


// Functions 

function Add(x:number,y:number):number|string{
    if(x<0)
        return 'x should be greater than 0 !';
    return x + y;
}

var result:number|string = Add(20,30);

// Optional Parameters

// function PrintBooks(title?:string,author?:string){
  
//     console.log(title,author);
// }

// PrintBooks();
// PrintBooks("Playing It My Way","Sachin Tendulkar");


// Default Parameters (Bydefault optional)

// function PrintBooks(title:string="Unknown",
// author:string="Unknown"){
  
//     console.log(title,author);
// }

// PrintBooks();
// PrintBooks(undefined,"Some Author");
// PrintBooks("Playing It My Way","Sachin Tendulkar");

// Rest Parameters

function PrintBooks(author:string,
    ...titles:string[]){
  
    console.log(author,titles);
}

PrintBooks("Virat Kohli","Driven");
PrintBooks("Dr. APJ Abdul Kalam","Wings Of Fire","India 2020");



// function Square(x){
//     return x * x;
// }

// Function as expression
// var Square = function(x){
//     return x * x;
// }

// Arrow function (ES6)
// var Square = (x) => {
//     return x * x;
// }
// OR
// var Square =  x => x * x; // The JS way !
var Square = (x:number):number => x *x;


cars.forEach(function(theCar){
    console.log(theCar);
});
// with arrow function
cars.forEach(theCar=>console.log(theCar));

// The Problem
// function Emp(){
//     this.salary = 200000;    
//     setTimeout(function(){
//          console.log(this.salary); // undefined
//     },3000)
// }
// solution
// function Emp(){
//     this.salary = 200000;    
//     setTimeout(()=>{
//          console.log(this.salary);
//     },3000)
// }

// var e = new Emp();

// Using Interfaces


interface IEmp{
    name:string;
    salary?:number;
    getSalary?():number;
}
var emp:IEmp = {name:'Amit',
salary:300000,
getSalary:function(){
        return this.salary
}};

class EMPLOYEE implements IEmp{
    name:string;
    salary:number;
    getSalary():number{
        return this.salary;
    }
}



// Classes

class Car{
    name:string;
    speed:number;
    constructor(name:string="i10",speed:number=100){
        this.name = name;
        this.speed = speed;
    }

    accelerate():string{
    //     console.log('The car ' 
    //     +this.name +
    //      " is running at " 
    //      + this.speed + " kmph !");
    return (`The car ${this.name}  is running at ${this.speed} kmph !`);
     }   
}
class JamesBondCar extends Car{
    canFly:boolean;    nitroPower:boolean;    
    constructor(n:string,s:number,fly:boolean,
        nitro:boolean){
            super(n,s);
            this.nitroPower = nitro;
            this.canFly = fly;
        }
        accelerate():string{
            return super.accelerate() + "Can Fly ? : "+ this.canFly;
        }
}
var jbc = new JamesBondCar("Aston Martin",
500,true,true);
jbc.accelerate();

// Enhanced Class Syntax

class EnhancedCar{
    constructor(public name:string="i20",public speed:number=200){

    }
}

var ec = new EnhancedCar();